# OnlineProductCatalog
OnlineProductCatalog is a full-stack e-commerce web app built with Spring Boot and Angular. It lets users browse products, manage their cart, and update their profile. With a clean UI and RESTful API integration, it’s a great project to learn how modern frontend and backend technologies work together.
